import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-icon-sources',
  templateUrl: './icon-sources.component.html',
  styleUrls: ['./icon-sources.component.scss']
})
export class IconSourcesComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
